package com.airlines.webservice.rest;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("/AirlinesServices/rest")


public class RestApplicationConfig extends javax.ws.rs.core.Application {

}


