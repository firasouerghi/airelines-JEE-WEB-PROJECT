package com.airlines.entities;

public enum FlightClass {
	
	Business ,
	Economic ,
	FirstClass
	
	

}
