package com.airlines.entities;

public enum FlightDestinations {
	Tunis,
	Rome ,
	Tokyo,
	Paris,
	Madrid

}
