package com.airlines.entities;

public enum AirplaneModel {

	AirbusA380,
	Boeing777,
	Boeing747,
	AirbusA340,
	
	
	

}
