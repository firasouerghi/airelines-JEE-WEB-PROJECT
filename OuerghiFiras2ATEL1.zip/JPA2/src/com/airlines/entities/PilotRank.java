package com.airlines.entities;

public enum PilotRank {
	
	Captain,
	Junior_Officer,
	First_Officer

}
