package com.airlines.entities;

public enum Gender {
	Male ,
	Female

}
