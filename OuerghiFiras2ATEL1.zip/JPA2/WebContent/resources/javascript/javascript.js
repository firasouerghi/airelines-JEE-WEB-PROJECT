/**
 * 
 */

$('.carousel').carousel({
    interval: 1//changes the speed
})

