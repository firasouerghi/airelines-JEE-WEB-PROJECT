/**
 * 
 */

$('.carousel').carousel({
    interval: 3000 //changes the speed
})

